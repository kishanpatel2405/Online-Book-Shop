<?php
include "conncetion.php";
session_start();

if($_POST["submit"]=="Submit")
{
	$b_cat_id=$_POST["b_cat_id"];
	
	$bname=$_POST["bname"];
	$bauthor=$_POST["bauthor"];
	$bprice=$_POST["bprice"];
	$bpublisher=$_POST["bpublisher"];
	$blanguage=$_POST["blanguage"];
	$bedition=$_POST["bedition"];
	
	//$fname=$_POST["bimage"];
	$fnam=$_FILES["bimage"]["name"];
	$dst="./image/".$fnam;
	$f_tmp_name = $_FILES["bimage"]["tmp_name"];
	move_uploaded_file($f_tmp_name,$dst);
		
	$category = mysqli_query("select cname from category where id=".$b_cat_id."");
	$category_name = mysqli_fetch_assoc($category);
	$category_name = implode($category_name);
  
	$s="insert into product(b_cat_id,bcategory,bname,bauthor,bprice,bpublisher,blanguage,bedition,
	bimage) values ('".$b_cat_id."','".$category_name."','".$bname."','".$bauthor."','".$bprice."','".$bpublisher."','".$blanguage."','".$bedition."','".$fnam."')";   
	
	 
	if(mysqli_query($s))
	//header("Location:view_product.php");
	{
		$_SESSION['product']=1;
	header('Location:add_product.php');
	}
	else
	{
		echo"no";
	}
	
}
else
{
	echo "not conncet";
}
	
	
?>

		