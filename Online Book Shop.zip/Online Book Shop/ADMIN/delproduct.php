<?php
include "conncetion.php";
session_start();
	
//	include"connect.php";
	$s="delete from product where p_id=".$_GET['id'];
	
	if( $data=mysqli_query($s))
		
	{
			
			$_SESSION['delete']=1;
		header("Location: delete_product.php");
	}
	else
	{
		echo "hello";
	
	}
	
	
?>
