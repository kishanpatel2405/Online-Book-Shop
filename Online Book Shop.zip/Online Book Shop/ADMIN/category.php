<?php
include "include.php";
	include("header.php");
	if(isset($_SESSION['cat']))
		{
			if($_SESSION['cat'] == 1)
			{
				echo "<script type='text/javascript'>";
				echo "alert('Category Added Successfully')";
				echo "</script>";
				unset($_SESSION['cat']);
			
		}
	}
?>


<style>

input[type=text]

 {
    font-size:15px;
	width: 50%;
	height: 5%;
     padding: 16px 12px;
    margin: 10px 25px;
    display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}
	
	
.subbtn {
	width:15%;
   padding: 16px 12px;
   
    background-color:green;
	border: solid 1px green;
	color: white;
	font-size: 12px;
	cursor: pointer;
}
</style>
	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			
		</div>
	</div>
<div align="left">
<h3 align="center"> <font size="15">Add Category</font></h3><br><br>
<form method="POST" action="addcat.php" >
				Category Name
				<input type="text" name="cname" required>
				
				
				<input type="submit" name="submit" class="subbtn" value="Submit">
			</form>
			</div>

	<?php 
	include "footer.php";
	?>