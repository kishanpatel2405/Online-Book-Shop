<?php
include "include.php";
include "header.php";
?>

<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			<ul class="categories">
				<li>
					
					
					
							
						<li><img align="right" src="css/images/sidelog2.png" alt="" /></li>
				
				</li>
				
			</ul>
		</div>
	</div>
<div>

<h3 align="center"><font size="15">Wel Come Admin</font></h3>
</div><br><br>
<ul><div align="center">
<img align="center" src="css/images/book2.jpg" alt="" /></li>
</div>
</ul>	







<?php
include "footer.php";
?>