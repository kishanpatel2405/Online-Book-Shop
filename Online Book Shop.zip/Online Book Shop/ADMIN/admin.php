<?php

include "header.php";
?>
<style>
		
input[type=text], 
input[type=password] {
    font-size:15px;
	width: 50%;
    padding: 16px 12px;
    margin: 8px 0;
    display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}

button {
      
	background-color: #4CAF50;
    color: white;
		padding: 12px 16px;
		margin: 8px 9px;
	
  border: none;
    cursor: pointer;
    width: 10%;
}
 .loginbutton{ padding: 14px 20px;	
    background-color:green;
	border: solid 1px green;
	width: 15%;
	color: white;
	font-size: 12px;
	cursor: pointer;
}
button:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: 15%;
    padding: 14px 20px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
   
    
	padding-left:50%
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
.logou{
padding-left:32%;
	
	}

</style>


	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			<ul class="categories">
				<li>
					
					
							<li><img align="right" src="css/images/sidelog.png" alt="" /></li>
							<li> </li>

						<li><img align="right" src="css/images/sidelog2.png" alt="" /></li>
				
				</li>
				
			</ul>
		</div>
	</div>
 <div align="center" class="logou">

 <img src="css/images/loginlogo.png"></div><br>
<h3 align="center"><font size="9"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Admin Login </font></h3><br>	

<form  method="POST" action="adminlogin.php">
 
  <div class="containe" align="center">
  
    <label ><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required><br>

    <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" required><br>
        
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
   <input  class="loginbutton" type="submit"  name="submit" value="Login"/>

	
  </div>
  </form>
 
</body>
</html> 
  
		

		






