<html >
<head>
	<title>Books Shop</title>
	<!--<meta http-equiv="Content-type" content="text/html; charset=utf-8" />-->

	<link rel="shortcut icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="php" href="check.php" />
	<link rel="php" href="login.php" />
	<script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.jcarousel.min.js"></script>
	<!--[if IE 6]>
		<script type="text/javascript" src="js/png-fix.js"></script>
	<![endif]-->
	<script type="text/javascript" src="js/functions.js"></script>
	</head>
<body>
	<!-- Header -->
	<div id="header" class="shell">
		<div id="logo"><h1><a href="#"></a></h1><span><a href="#"></a></span></div>
		<!-- Navigation -->
	<div id="navigation" align="right">
			<ul>
		<?php
			
				if(isset($_SESSION['fuser']))
				{
		
					//echo '<li><a href="adminhome.php" class="active">Home</a></li>';
					echo '<li> <a href="add_product.php">Add Product</a></li>';
					echo'<li> <a href="view_product.php"> View product</a></li>';
					echo'<li> <a href="update.php"> Update product</a></li>';
					echo '<li> <a href="delete_product.php"> Delete product</a></li>';
					echo'<li> <a href="category.php"> Add Category</a></li>';
					echo '<li> <a href="view_category.php">View Category</a></li>';
					echo '<li> <a href="view_client.php">View Client</a></li>';
					echo '<li> <a href="view_order.php">View Order</a></li>';
					echo '<li> <a href="logout.php">Logout</a></li>';
				}
				else
				
				
					
?>				
			</ul>	
		</div>
		<!-- End Navigation -->
		<div class="cl">&nbsp;</div>
		<!-- Login-details -->
		<div id="login-details" >
			<p>Welcome, Hello,
			<?php
		
			if(isset($_SESSION['fuser']))
			{
			echo $_SESSION['fuser'];
			
			}
			
			?>
			
			
			
			 </p>.
		</div>
		<!-- End Login-details -->
	</div>
	<!-- End Header -->
	<!-- Slider -->
	<div id="slider">
		<div class="shell">
			<ul>
				<li>
					<div class="image">
						<img src="css/images/books.png" alt="" />
					</div>
					<div class="details">
						<h2>Bestsellers</h2>
						<h3>Just One Click</h3>
						<p class="title"></p>
						<p class="description"><h4><font size="4" >There are a number of good stores from where you can buy books online. Though, the pricing of the books varies from store to store. 	</font></h4></p>
						<!--	<a href="#" class="read-more-btn">Read More</a>-->
					</div>
				</li>
				<li>
					<div class="image">
						<img src="css/images/bookss.png" alt="" />
					</div>
					<div class="details">
						<h2>Bestsellers</h2>
						<h3>Buy Books Online</h3>
						<p class="title"></p>
						<p class="description"><h4><font size="4">BestSellers is the fastest way to buy books from online book sellers in India.</font></h4></p>
					<!--	<a href="#" class="read-more-btn">Read More</a>-->
					</div>
				</li>
				<li>
					<div class="image">
						<img src="css/images/book3.png" alt="" />
					</div>
					<div class="details">
						<h2>Bestsellers</h2>
						<h3>Best Collection</h3>
						<p class="title"></p>
						<p class="description"><h4><font size="4">Reading books is the favourite pastime of many people. From bestsellers to new & future releases, the choices are exhaustive when you shop onlineat India's Largest Bookstore.</font></h4></p>
					<!--	<a href="#" class="read-more-btn">Read More</a>-->
					</div>
				</li>
				<li>
					<div class="image">
						<img src="css/images/book4.png" alt="" />
					</div>
					<div class="details">
						<h2>Bestsellers</h2>
						<h3>Different Book Collection</h3>
						
						<p class="title"></p>
						<p class="description"><h4><font size="4">It Provide Different type of books like Comedy,History,Kids etc.</font></h4></p>
						<!--	<a href="#" class="read-more-btn">Read More</a>-->
					</div>
				</li>
			</ul>
			<div class="nav">
				<a href="#">1</a>	
				<a href="#">2</a>
				<a href="#">3</a>
				<a href="#">4</a>
			</div>
		</div>
	</div>
	<!-- End Slider -->
	<!-- Main -->