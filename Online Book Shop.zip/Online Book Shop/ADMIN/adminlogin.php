<?php
include "conncetion.php";
session_start();


 
 if($_POST["submit"]=="Login")
  $user=$_POST['uname']; 
$pass=$_POST['pass'];
$sql="select * from admin_login form where uname='".$user."' and pass='".$pass."'";
$result=mysqli_query($con, $sql);
$row=mysqli_fetch_array($result);
$_SESSION['fuser']=$row['uname'];
if($user==$row['uname'] && $pass==$row['pass'])
{
	//$_SESSION['login'] = 1;
	header('Location:adminlogincheck.php');
	
}
else
{	
	//$_SESSION['login'] = 2; 
	header('Location:admin.php');
	//header("Location:loginform.php");
}

		
?>
