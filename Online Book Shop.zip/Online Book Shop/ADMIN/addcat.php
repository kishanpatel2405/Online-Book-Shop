<?php
include "conncetion.php";
session_start();

if($_POST["submit"]=="Submit")
{
	
	$cname=$_POST['cname'];
	
   
	$s="insert into category(cname) values('".$cname."')";
	
	if(mysqli_query($con, $s))
	{
		
		$_SESSION['cat']=1;
	header('Location:category.php');
	}
	else
	{
		echo "no";
	}
}

else
{	
	{
		
		echo "not conncet";
	}
}

	
	?>
	
	