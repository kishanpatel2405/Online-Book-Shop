





<?php
include "include.php";

include "header.php";
include "conncetion.php";
if(isset($_SESSION['update']))
		{
			if($_SESSION['update'] == 1)
			{
				echo "<script type='text/javascript'>";
				echo "alert('Product Updated  Successfully')";
				echo "</script>";
			unset($_SESSION['update']);
			}
			
		}
		

?>

<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
			</li>	
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
		</div>
	</div>

<h3 align="center"> <font size="15">Update Book</font></h3><br><br><br>
<?php

			

	$res=mysqli_query($con, "select * from product");
				
	echo"<table border='1'>
	
	<tr>

	<th>	<font color='red'>Id</th>
	<th><font color='red'>Book Category ID</th>
	<th><font color='red'>Book Category </th>
	<th><font color='red'>Book Name</th>
	<th><font color='red'>Book Author</th>
	<th><font color='red'>Book Price</th>
	<th><font color='red'>Book Publsiher</th>
	<th><font color='red'>Book Language</th>
	<th><font color='red'>Book Edition</th>
	
	<th><font color='red'>Book Image</th>
	<th><font color='red'>Update</th>
	</tr> ";
	
	//<th>Book Delete</th>
	while($row=mysqli_fetch_assoc($res))
	{
		echo "<tr>";
		echo "<th>".$row['p_id']."</th>";
		echo "<th>".$row['b_cat_id']."</th>";
		echo "<th>".$row['bcategory']."</th>";
		echo "<th>".$row['bname']."</th>";
		echo "<th>".$row['bauthor']."</th>";
		echo "<th>".$row['bprice']."</th>";
		echo "<th>".$row['bpublisher']."</th>";
		echo "<th>".$row['blanguage']."</th>";
		echo "<th>".$row['bedition']."</th>";
		
		
		echo "<th><img height='80' width='66'src='image/".$row['bimage']."' /></th>";
		echo "<td> <a href='update_product.php?id=".$row['p_id']."'>
		<img height='30' width='60'src='css/images/update.jpg'/></a></td>";
		//echo "<td> <a href='delete_product.php?id=".$row['id']."'>Delete</a></td>";
		
				
		echo"</tr>";
	}
	echo"</table>";
	echo"<br>";


include "footer.php";


	?>
