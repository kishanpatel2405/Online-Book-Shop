
<?php 

include "include.php";
include "conncetion.php";
 include "header.php"; 
 
 $res=mysqli_query($con, "select * from category");
		
if(isset($_SESSION['product']))
		{
			if($_SESSION['product'] == 1)
			{
				echo "<script type='text/javascript'>";
				echo "alert('Product Added Successfully')";
				echo "</script>";
				session_destroy();
			}
			
		}
		
?>
	
<style>

input[type=text],

input[type=number],
input[type=file]
 {
    font-size:15px;
	width: 150%;
	height: 3%;
     padding: 10px 5px;
    margin: 10px 25px;
    display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}
.cat
{
	 padding: 16px 10px;
    margin: 10px 25px;
	width: 150%;
	height: 5%;
	font-size:15px;
	display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}
.logou{
padding-left:32%;
	
	}
.signupbtn {
	width:15%;
   padding: 14px 20px;	
    background-color:green;
	border: solid 1px green;
	color: white;
	font-size: 12px;
	cursor: pointer;
}
.cancelbtn {
    width: 15%;
    padding: 14px 20px;
    background-color: blue;
}
</style>


	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			
		</div>
	</div>
<div align="left">
<h3 align="center"><font size="10">Add Product</font></h3><br>
<form  method="POST" action="product.php" enctype="multipart/form-data">

<div align="center" >

	<table >
	<tr>
			<td><b>Category :-</b></td>
			<td> <select name="b_cat_id" class="cat">
				<option value="" hidden>Select Category</option>
									<?php
										//if(mysqlii_num_rows($cat_res) == 0) { echo "No Categories..."; }
													
											while($r_row=mysqli_fetch_array($res))
											{
											echo '<option value="'.$r_row["id"].'
											">'.$r_row["cname"].'</option>';
									
								
											}
									?>
								</select><br>
</td>
		</tr>
<!--Category ID  <input type="text" name="b_cat_id" required><br><br>-->

		<tr>
			<td><b>Book Name :-</b></td>
			<td><input type="text" name="bname"  required></td>
		</tr>
		<tr>
			<td><b>Book Author :-</b></td>
			<td><input type="text" name="bauthor"  required></td>
		</tr>
		<tr>
			<td><b>Book Price :-</b></td>
			<td><input type="number" name="bprice"  required></td>
		</tr>
		
		<tr>
			<td><b>Book Publisher :- </b></td>
			<td><input type="text" name="bpublisher"  required></td>
		</tr>
		<tr>
			<td><b>Book Language :-</b> </td>
			<td><input type="text" name="blanguage"  required></td>
		</tr>
		<tr>
			<td><b>Book Edition :-</b> </td>
			<td><input type="text" name="bedition"  required></td>
		</tr>
		
		
		<tr>
			<td><b>Book Image :-</b> </td>
			<td><input type="file" name="bimage" required>	</td>
		</tr>
	</table>
<input type="submit" name="submit" value="Submit" class="signupbtn" >

</div>
	
</form>

<?php
include "footer.php";
?>