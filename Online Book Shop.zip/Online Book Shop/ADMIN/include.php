<?php
session_start();
if(!isset($_SESSION['fuser']))
{
	
	header("Location:admin.php");
}	

?>