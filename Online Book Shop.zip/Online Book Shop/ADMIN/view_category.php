<?php
include "include.php";
include "header.php";
include "conncetion.php";
?>

<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					</li>	
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			</div>
	</div>

<h3 align="center"> <font size="15">View Category</font></h3><br><br><br>

<div align="center">
<?php
$res=mysqli_query($con, "select * from category");
	echo"<table border='1'>
		<tr>
	<th>Book Category ID</th>
	<th>Category Name</th>
		</tr>";
	//<th>Update</th>
	//<th>Book Delete</th>
	while($row=mysqli_fetch_assoc($res))
	{
		echo "<tr>";
		echo "<th>".$row['id']."</th>";
		echo "<th>".$row['cname']."</th>";
		
		
				
		echo"</tr>";
	}
	echo"</table>";
	echo"<br>";
?>
</div>
<?php
include "footer.php";


	?>
	