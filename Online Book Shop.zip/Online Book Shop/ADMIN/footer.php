<div class="cl" >&n	bsp;</div>
			<!-- Best-sellers -->
			<div id="best-sellers" align="center">
				
				
			</div>
			<!-- End Best-sellers -->
		</div>
		<!-- End Content -->
		<div class="cl">&nbsp;</div>
	</div>
	<!-- End Main -->
	<!-- Footer -->
	<div id="footer" class="shell">
		<div class="top">
			<div class="cnt">
				<div class="col about">
					<h4><font color="white">About BestSellers</h4>
					<p>When you shop online, there are hot pre-orders. You can easily secure that book youv have always wanted to read, as the book will be delivered at your doorstep soon after its officia	l release. You also have easy access to most of the new arrivals, with book descriptions that help you get an idea about the book without spoilers.</font> <br /><br><br><font color="white" size="5">Best Sellers </Font> </p>
				</div>
				<div class="col store">
					
				</div>
				<div align="right"><br><br>
				Admin: Vaghasiya Kishan 
				</div>
				<div class="cl"></div>
				<div class="copy">
					<a href="home.php"><p> <marquee behavior="alternate"><font color="white" face="verdena" size=
"5">Best Seller - <i>Online Book Shop</font></marquee></p></a>
				</div>
				
			</div>
		</div>
	</div>
	<!-- End Footer -->