<?php
include "include.php";
include "header.php";
include "conncetion.php";
?>

<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>	
				</li>				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			
		</div>
	</div>

<h3 align="center"> <font size="15">View Client</font></h3><br><br><br>
<div align="center">

<?php
$res=mysqli_query($con, "select * from signup");
				
	echo"<table border='1'>
	
	<tr>
	<th> Client id</th>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Address</th>
	<th>City</th>
	<th>Phone No.</th>
	<th>User Name</th>
	<th>Email</th>
	</tr>";
	//<th>Update</th>
	//<th>Book Delete</th>
	while($row=mysqli_fetch_assoc($res))
	{
		echo "<tr>";
		echo "<th>".$row['id']."</th>";
		echo "<th>".$row['fname']."</th>";
		echo "<th>".$row['lname']."</th>";
		echo "<th>".$row['address']."</th>";
		echo "<th>".$row['city']."</th>";
		echo "<th>".$row['number']."</th>";
		echo "<th>".$row['username']."</th>";
		echo "<th>".$row['email']."</th>";
		
		//echo "<td> <a href='update_product.php?id=".$row['id']."'>Update</a></td>";
		//echo "<td> <a href='delete_product.php?id=".$row['id']."'>Delete</a></td>";
		echo"</tr>";
	}
	echo"</table>";
	echo"<br>";
include "footer.php";


	?>

</div>
	



