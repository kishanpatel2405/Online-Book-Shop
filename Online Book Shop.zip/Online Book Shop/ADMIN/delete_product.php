<?php
include "include.php";
include "conncetion.php";
include "header.php";
if(isset($_SESSION['delete']))
		{
			if($_SESSION['delete'] == 1)
			{
				echo "<script type='text/javascript'>";
				echo "alert('Product Deleted  Successfully')";
				echo "</script>";
				unset($_SESSION['delete']);
			}
		}
?>

<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
					
					
					
							
						
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			
		</div>
	</div>

<h3 align="center"> <font size="15">Delete Product</font></h3><br><br><br>


<?php
			
	$res=mysqli_query($con, "select * from product");
				
	echo"<table border='1'>
	
	<tr>
	<th>id</th>
	<th>Book Category ID</th>
	<th>Book Category </th>
	<th>Book Name</th>
	<th>Book Author</th>
	<th>Book Price</th>
	<th>Book Publsiher</th>
	<th>Book Language</th>
	<th>Book Edition</th>
	
	<th>Book Image</th>
	<th>Book Delete</th>
	</tr>";
	//<th>Update</th>
	//<th>Book Delete</th>
	while($row=mysqli_fetch_assoc($res))
	{
		echo "<tr>";
		echo "<th>".$row['p_id']."</th>";
		echo "<th>".$row['b_cat_id']."</th>";
		echo "<th>".$row['bcategory']."</th>";
		echo "<th>".$row['bname']."</th>";
		echo "<th>".$row['bauthor']."</th>";
		echo "<th>".$row['bprice']."</th>";
		echo "<th>".$row['bpublisher']."</th>";
		echo "<th>".$row['blanguage']."</th>";
echo "<th>".$row['bedition']."</th>";
		
		
		echo "<th><img height='80' width='66' src='image/".$row['bimage']."' /></th>";
		//echo "<td> <a href='update_product.php?id=".$row['id']."'>Update</a></td>";
		echo "<td> <a href='delproduct.php?id=".$row['p_id']."'>Delete</a></td>";
		
				
		echo"</tr>";
	}
	echo"</table>";
	echo"<br>";
?>
<?php include "footer.php";?>
