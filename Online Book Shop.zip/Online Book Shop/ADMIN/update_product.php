<?php
	include "header.php";
	include "conncetion.php";
	
//	include"connect.php";
	$s="select b_cat_id,bcategory,bname,bauthor,bprice,bpublisher,blanguage,bedition,bimage from product where p_id=".$_GET['id'];
	//$res=mysqli_query("select * from category");
	$data=mysqli_query($con, $s);
	$row=mysqli_fetch_assoc($data);
	
			$res=mysqli_query($con, "select * from category");
				
?>

<style>

input[type=text],

input[type=number],
input[type=file]
 {
    font-size:15px;
	width: 150%;
	height: 3%;
     padding: 10px 5px;
    margin: 10px 25px;
    display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}
.cat
{
	 padding: 16px 10px;
    margin: 10px 25px;
	width: 150%;
	height: 5%;
	font-size:15px;
	display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}
	
.signupbtn {
	width:15%;
   padding: 14px 20px;	
    background-color:green;
	border: solid 1px green;
	color: white;
	font-size: 12px;
	cursor: pointer;
}

</style>



	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			<ul class="categories">
				<li>
					
					
							</li>
				
			</ul>
		</div>
	</div>

	
	<h3 align="center"><font size="10">Update Product</font></h3><br><br>
<form  method="POST" action="update_process.php" enctype="multipart/form-data">

<div align="center" >

	<table>
	<tr>
			
			<td><b>Category :-</b></td>
			<td> <select name="b_cat_id" class="cat">
			<!--<option value="" hidden>Select Category </option>		-->	
				<?php
										/* echo '<option value="'.$row["b_cat_id"].'
											">'.$row["bcategory"].'</option>'; */
										//if(mysqlii_num_rows($cat_res) == 0) { echo "No Categories..."; }
													
											while($r_row=mysqli_fetch_array($res))
											{
												if($row['bcategory'] == $r_row['cname'])
												{
													echo '<option selected value="'.$r_row["id"].'">'.$r_row["cname"].'</option>';
												}
												else
												{										
													echo '<option value="'.$r_row["id"].'">'.$r_row["cname"].'</option>';							
												}
											}
									?>	
								</select>
</td>
		
		</tr>
	<tr>
	<td><b>Book Name</b> </td>
<td>	<input type="text" name="bname" value="<?php echo $row['bname'];?>" /></td>
	</tr>
	
	<tr>
	<td><b>Book Author</b></td>
<td>	<input type="text" name="bauthor" value="<?php echo $row['bauthor'];?>" required min="5"/></td>
	</tr>
	<tr>
	<td><b>Book Price</b></td>
<td>	<input type="number" name="bprice" value="<?php echo $row['bprice'];?>" required min="5"/></td>
	</tr>
	<tr>
	<td><b>Book Publisher</b></td>
<td>	<input type="text" name="bpublisher" value="<?php echo $row['bpublisher'];?>" /></td>
	</tr>
	<tr>
	<td><b>Book Language </b></td>
<td>	<input type="text" name="blanguage" value="<?php echo $row['blanguage'];?>" /></td>
	</tr>
	<tr>
		<td><b>Book Edition :-</b> </td>
			<td><input type="text" name="bedition" value="<?php echo $row['bedition'];?>" required></td>
		</tr>
		
	
	
	<td><b>Book Image </b></td>
<td>	<input type="file" name="bimage"></td>
<td><h3> Old Image </h3>	<img width="40" height="70"src="image/<?php echo $row['bimage'];?> "></td>
	</tr>
	<input type="hidden" value="<?php echo $_REQUEST['id'];?>" name="ID" />


	</table>
	</form>

<input type="submit" name="submit" value="Submit" class="signupbtn"/></br></td>
<?php

	
	include "footer.php";

?>
