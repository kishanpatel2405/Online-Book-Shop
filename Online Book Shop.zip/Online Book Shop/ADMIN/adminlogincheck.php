<?php
session_start();
if(isset($_SESSION['fuser']))
{
	
	header('Location:adminhome.php');
	
}
else
{
   
   header('Location:admin.php');
}
?>