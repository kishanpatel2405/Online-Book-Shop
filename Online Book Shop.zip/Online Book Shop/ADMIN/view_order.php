<?php
include "include.php";
include "header.php";
include "conncetion.php";
?>


<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
				</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			
		</div>
	</div>

<h3 align="center"> <font size="15">View Order</font></h3><br><br><br>


<?php

		
		
		 $l = "select * from final_order";
		
			$res=mysqli_query($con, $l);
		
				
	echo"<table border='1'>
	
	<tr>
	<th>Product ID</th>
	
	<th>First Name </th>
	<th>Last Name</th>
	<th>Address</th>
	 <th>City</th>
	<th>Phone No.</th>
	 <th>Product Name</th>
	 <th>Category</th>
	  <th>Author</th>
	 <th>Language</th>
	  <th>Price</th>
	 <th>Image</th>
	 <th>Date</th>";
	
	echo "</tr>";
	//<th>Update</th>
	//<th>Book Delete</th>
	while($rows=mysqli_fetch_assoc($res))
	{
		echo "<tr>";
		echo "<th>".$rows['pid']."</th>";
		echo "<th>".$rows['fname']."</th>";
		echo "<th>".$rows['lname']."</th>";
		echo "<th>".$rows['address']."</th>";
		echo "<th>".$rows['city']."</th>";
		echo "<th>".$rows['number']."</th>";
		echo "<th>".$rows['pname']."</th>";		
		echo "<th>".$rows['category']."</th>";
		echo "<th>".$rows['author']."</th>";
		echo "<th>".$rows['language']."</th>";		
		echo "<th>".$rows['price']."</th>";		
		echo "<th><img height='80' width='66'src='image/".$rows['image']."' /></th>";
		echo "<th>".$rows['date']."</th>";
	//echo "<th><img height='80' width='66'src='image/".$rows['bimage']."' /></th>";
		//echo "<td> <a href='update_product.php?id=".$row['id']."'>Update</a></td>";
		//echo "<td> <a href='delete_product.php?id=".$row['id']."'>Delete</a></td>";
		
				
		echo"</tr>";
	}
	echo"</table>";
	echo"<br>";





	?>
<?php

include "footer.php";
?>