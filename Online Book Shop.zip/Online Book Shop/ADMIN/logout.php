<?php


//Delete all session variables
 session_start();

 unset($_SESSION['fuser']);
session_destroy();


header("Location:admin.php");
// Jump to login page


?>