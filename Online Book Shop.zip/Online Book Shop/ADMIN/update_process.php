<?php

session_start();
include "conncetion.php";
  
if($_POST["submit"]=="Submit")
	
{
	//$id=$_POST["id"];
	$b_cat_id=$_POST["b_cat_id"];
	
	$category = "select cname from category where id=".$b_cat_id."";
	$category = mysqli_query($category);
	$category = mysqli_fetch_assoc($category);
	$category = implode($category);
	
	$bname=$_POST["bname"];
	$bauthor=$_POST["bauthor"];
	$bprice=$_POST["bprice"];
	$bpublisher=$_POST["bpublisher"];
	$blanguage=$_POST["blanguage"];
	$bedition=$_POST["bedition"];
	
	$ID = $_POST['ID'];
	
	$fnam=$_FILES["bimage"]["name"];
	$dst="./image/".$fnam;
	$f_tmp_name = $_FILES["bimage"]["tmp_name"];
	move_uploaded_file($f_tmp_name,$dst);
	
	echo $u="UPDATE product SET b_cat_id=".$b_cat_id.", bcategory='".$category."',bname='".$bname."',bauthor='".$bauthor."',bprice='".$bprice."',bpublisher='".$bpublisher."',blanguage='".$blanguage."',bedition='".$bedition."' ,bimage='".$fnam."'where p_id=".$ID;
	
	
	if(mysqli_query($u))
	
	{
		echo "yes";
			$_SESSION['update']=1;
	
	
	header("Location:update.php");
	}
	else
	{
		echo "no";
	} 
}
else
{
echo "no";
}
?>