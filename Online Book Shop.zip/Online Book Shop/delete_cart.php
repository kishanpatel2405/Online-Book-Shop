<?php
	include "conncetion.php";
//mysqlii_connect("localhost","root","");
  
	$id=$_GET['id'];
	
	$q="delete from cart where pid=$id";
	
	mysqli_query($q);
	
	header("location:view_cart.php");
?>