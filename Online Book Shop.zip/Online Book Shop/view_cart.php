<?php
include "header.php"; 
include "conncetion.php";
include "config.php";
?>
<style>

input[type=submit] {
	background-color: #4CAF50;
	color: white;
   width: 20%;
	height: 10%;
	font-size:12.5px;
   padding: 16px 12px;
    margin: 10px 25px;
	}
</style>
<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>	
				</li>
				</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	<div id="main" class="" >
	<div align="center" class="logoo">
</div>					
<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
				<li></li>	
				<li></li>
				</li>
				</ul>
</div>
	</div>
 <?php
			$q="SELECT * FROM product WHERE p_id IN ( SELECT pid FROM cart WHERE u_id = '".$_SESSION['user']."')";
			$chq=mysqli_query($con, $q) or die (mysqli_error());
	 ?>
		<?php $chk = mysqli_fetch_row($chq); if($chk[0] != '') {
			?>
<div align="center">
<h3><font size="15">Your Cart</font></h3><br><br>
 <table border="1"width="591" cellspacing="8" cellpadding="5">
		 <tr bgcolor="#ddd">
                          <th> Book Name </th> 
                   	  	  <th> Book Category </th> 
						  <th> Book Author</th>  
                          <th> Book Price</th>
						  <th> Book Language</th>
                          <th> Book Image</th>
                          <th> Delete From Cart</th>
           	   </tr>
						<?php $res=mysqli_query($con, $q) or die (mysqli_error());
						$count = 1;
							$total_price = 0;
							
							while($row = mysqli_fetch_assoc($res))
							{
								
						?>
							<tr>
							<td align="center"><?php echo $row['bname'] ?></td>
								<td align="center"><?php echo $row['bcategory'] ?></td>
								<td align="center"><?php echo $row['bauthor'] ?></td>
                                <td align="center"><?php echo $row['bprice'] ?></td>
								<td align="center"><?php echo $row['blanguage'] ?></td>
                                <td align="center"><img height='80' width='66'src="ADMIN/image/<?php echo $row['bimage'] ?>"></td>
                                <td width="79" align="center"><a href="delete_cart.php?id=<?php echo $row['p_id']; ?>"/>
										<img width="50" height="60" src="css/images/deletecart.jpg"></a></td>
									<form action="ordersuccess.php" method="POST">
									 <input type="hidden" name="pr<?php echo $count; ?>" value="<?php echo $row['p_id']?>" />
									 <input type="hidden" name="prname<?php echo $count; ?>" value="<?php echo $row['bname']?>" />
									 <input type="hidden" name="prprice<?php echo $count; ?>" value="<?php echo $row['bprice']?>" />
									 <input type="hidden" name="primage<?php echo $count; ?>" value="<?php echo $row['bimage']?>" />
									 <input type="hidden" name="prcategory<?php echo $count; ?>" value="<?php echo $row['bcategory']?>" />
									 <input type="hidden" name="prauthor<?php echo $count; ?>" value="<?php echo $row['bauthor']?>" />
									 <input type="hidden" name="prlanguage<?php echo $count++; ?>" value="<?php echo $row['blanguage']?>" />
									 </td>							
									</tr>
						 <?php
									$total= $total_price += $row['bprice'] ;
									
							}
					
						?>
						</table><br><br>
							<b><h3>Grand Total:</b>
							<?php
							echo 	@$total;	
							?>
							</h3><input type='hidden' name='total' value='<?php echo @$total; ?>' />
							<input type='hidden' name='products' value='<?php echo --$count; ?>'><br /><br />
		<center><input type="submit" name="submit" value="Buy Now"><br><br></center></form>
<?php } else echo "<h3><center>Your Cart Is Empty...</center></h3><br><br>"; ?>
<a href="index.php"><h3><center>Back To Shopping </center></h3></a>
<?php 
include "footer.php";
?>