<?php

include "header.php"; 
include "conncetion.php";



  $l = "select * from product  where  p_id = '".$_REQUEST["pid"]."'";
					$result = mysqli_query($con, $l);
					$row = mysqli_fetch_assoc($result);
			
			
			?>

<style>

.cart {
	width:60%;
   padding: 14px 20px;	
    background-color:red;
	border: solid 1px green;
	color: white;
	font-size: 12px;
	cursor: pointer;
}
.buy {
	width:40%;
   padding: 14px 20px;	
    background-color:green;
	border: solid 1px green;
	color: white;
	font-size: 12px;
	cursor: pointer;
}
</style>
<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
			</li>
		</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	<div id="main" class="" >
	<div align="center" class="logoo">
</div>					
<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					<li><img height="200" width="180" align="right" src="css/images/carton.png" alt="" /></li>	
						<li><img height="200" width="180" align="right" src="css/images/book animation.gif" alt="" /></li>	
						<li><img height="200" width="180" align="right" src="css/images/cartoon.jpg" alt="" /></li>	
						</li>
					</li>
				</ul>
	</div>
	</div>

<div align="center">
<table>
<tr>
<td>&nbsp; &nbsp; &nbsp; <img height="200" width="150" src="ADMIN/image/<?php echo $row["bimage"]  ?>"  class="img"/><br><br></td>
</tr><h3><font size="2">
<tr><td><b>Name:-</b></td>
<td><?php echo $row["bname"] ?><br><br></td>
</tr>
	<tr>
								<td>
								<b>Category:- </b></td>
								<td><?php echo $row["bcategory"] ?><br><br></td>
								</tr>
								<tr>
								<td><b>Author:- </b></td>
								<td><?php echo $row["bauthor"] ?><br><br></td>
								</tr>
								<tr>
								
								<td><b>Book Publisher :- </b></td>
								<td><?php echo $row["bpublisher"] ?><br><br></td>
								</tr>
								<tr>
								
								<td><b>Book Language :- </b></td>
								<td><?php echo $row["blanguage"] ?><br><br></td>
								</tr>
								<tr>
								<td><b>Edition :- </b></td>
								<td><?php echo $row["bedition"] ?><br><br></td>
								</tr>
								<tr>
								
								<td><b>Price:- </b></td>
								<td><?php echo $row["bprice"] ?><br><br></td>
								</tr>
								<tr>
								<td><b>Payment : </b></td>
								<td><font color="blue"><b>Cash On Delivery</b></font><br><br></td></tr>	
									<?php if(isset($_SESSION["user"])) { ?>
									<td align="right"><a href="add_to_cart.php ?id=<?php echo $row['p_id']; ?>"/>
                                     <img src="css/images/cart.jpg" width="150" height="50" hspace="20" align="middle"><br></a></td> 
									 
									
									
									<?php } ?>
									<?php if( ! isset($_SESSION["user"])) { ?><br><br>
									</tr>
									<tr>
									<td><li><h4><a href="login.php"><b>You Must Login First<b></a></h4></li></td>
									</tr>
									<?php } ?>
								</h3></font>
								</form>
								</table><br><br><br>
								</div>
								
<?php
include "footer.php";
?>