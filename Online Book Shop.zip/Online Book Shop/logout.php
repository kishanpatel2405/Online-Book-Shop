<?php


//Delete all session variables
 session_destroy();
unset($_SESSION['username']);
unset($_SESSION['login']);


header("Location:login.php");
// Jump to login page


?>