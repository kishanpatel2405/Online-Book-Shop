<?php	
	include "header.php";
	
	?>



	<style>
body{
    
    background-color: #3b3b3b ;
}
/* Full-width input fields */
input[type=text], input[type=password] {
    width: 50%;
	font-size:12.5px;
   padding: 16px 12px;
    margin: 10px 25px;
    display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 12px 16px;
    margin: 8px 9px;
    border: none;
    cursor: pointer;
    width: 20%;

}

	
.emaill
	{

 width: 50%;
    padding: 16px 12px;
    font-size:12.5px;	
	margin: 10px 25px;
    display: inline-block;
    border: 2px grove #ccc;
    box-sizing: border-box;
}


/* Extra styles for the cancel button */
.cancelbtn {
    padding: 14px 20px;
    background-color: 	red;
}
.signupbtn {
	width:15%;
   padding: 14px 20px;	
    background-color:green;
	border: solid 1px green;
	color: white;
	font-size: 12px;
	cursor: pointer;
}
.cancelbtn {
	width:15%;
   padding: 14px 20px;	
    background-color:red;
	border: solid 1px green;
	color: white;
	font-size: 12px;
	cursor: pointer;
}


/* Float cancel and signup buttons and add an equal width */
.cancelbtn {
    
	float: center;
    width: 15%;
}

/* Add padding to container elements */
.container {
    padding: 20px;
	
    margin: 8px 9px;
}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
	margin-left: 100px;
}
	


/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
    .cancelbtn, .signupbtn {
       width: 100%;
    }
}
.logoo{

padding-left:40%;
}

</style>


	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	<div id="main" class="" >
	
<div align="center" class="logoo">
<img src="css/images/signup.png">
</div>					
	<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
				<li><img align="right" src="css/images/signside.png" alt="" /></li>	
					&nbsp;	<li><img align="right" src="css/images/signside2.png" alt="" /></li>
				</li>
				</ul>
</div>
	</div>
<h3 align="center"><font size="9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Signup Form</font> </h3><br><br>

<form align="left" method="post" action="signup.php">
  <div class="containe" align="right">
    <label><b>Email</b></label>
	 <input class="emaill" type="email"  placeholder="Enter Email" name="email" required><br>
     <label><b>Enter First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="fname" required><br>	
	 <label><b>Enter Last Name</b></label>
    <input type="text" placeholder="Enter Last Name" name="lname" required><br>	
		<label><b>Enter Address</b></label>
    <input type="text" placeholder="Enter Your Address" name="address" min="20" required><br>	
	<label><b>Enter City</b></label>
    <input type="text" placeholder="Enter Your City" name="city" required><br>	
	<label><b>Enter Phone No.</b></label>
    <input type="text" placeholder="Enter Your Number" name="number" min="10" max="11" required><br>	
	<label><b>Enter User Name</b></label>
    <input type="text" placeholder="Enter User Name" name="username" required><br>	
	   <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required><br>
<div class="clearfix" align="center">&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp; &nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;		
	<div align="center">&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp; &nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;		&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp; &nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;		&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;		
	<input class="signupbtn" type="submit"  name="submit" value="Submit" />
	  <input type="reset" class="cancelbtn" value="Cancel"></div><br>
	 </div>
  <br><br>
<?php 
  include "footer.php";
?>
  </body>
</html>