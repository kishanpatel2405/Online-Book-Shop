<?php
include "conncetion.php";
include "header.php";

if(isset($_SESSION['cont']))
		{
			if($_SESSION['cont'] == 1)
			{
				echo "<script type='text/javascript'>";
				echo "alert('Thank You For Your Feedback')";
				echo "</script>";
				unset($_SESSION['cont']);
				//session_destroy();
			}
			
		}
		
if(isset($_SESSION['order']))
		{
			if($_SESSION['order'] == 2)
			{
				echo "<script type='text/javascript'>";
				echo "alert('Order Placed Successfully')";
				echo "</script>";
				unset($_SESSION['order']);
				//session_destroy('order');
			}
			
		}

		?>
	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					<h4>Categories</h4>
				<?php
				$res=mysqli_query($con, "select * from category");
				while($row=mysqli_fetch_array($res))
				{

			echo "<ul>";
			{
						echo '<li><a href="list.php?cat='.$row["id"].'">'.$row["cname"].'</a></li>';
					}
				
				echo "</ul>";
				}
				?>
			<br>
					<br>
						<li><img align="center" src="css/images/homeside.png" /></li>
						<li><img align="right"  /></li><br>
						<li><img align="right"  /></li><br>
						<li><img align="right" ></li><br>
			</li>
				
			</ul>
		</div>
		
		<div id="content">
			<!-- Products -->
			<div class="products">
				
				<?php
				
				$c_res=mysqli_query($con, "select * from category");
				while($cat_row = mysqli_fetch_assoc($c_res))
				{
					
				
				echo'<div><h3><a href="list.php?cat='.$cat_row["id"].'">'.$cat_row["cname"].'</h3></a></div>
						<ul>
							';
				

				$q="select * from product where b_cat_id=".$cat_row["id"]."   limit 0,4 ";
				$p_res= mysqli_query($con, $q);
				while($p_row = mysqli_fetch_assoc($p_res))
					{	

									
					echo'
					<li>
						<div class="product">
							<a href="details.php?pid='.$p_row["p_id"].'""" class="info">
								
									<span class="holder">
									<img src="ADMIN/image/'.$p_row["bimage"].'" alt="" />
									<span class="book-name"><b>'.$p_row["bname"].'</b></span>
									<span class="author"><b>By <i> '.$p_row["bauthor"].'<i></b></span>
									
								
								</span>
							</a>
								<a href="details.php?pid='.$p_row["p_id"].'"" class="buy-btn">BUY NOW <span class="price"><span class="low"></span>'.$p_row["bprice"].'</span></a>
						</div>
					</li>

					
					';
					}
				
					echo '</ul>';
				
				}
				?>	
			
				
			</div>	
			<div class="cl">&nbsp;</div>
			<?php
			include "footer.php";
			?>
</body>
</html>