<?php
include "conncetion.php";

session_start();

$ssql = 'select * from product where p_id= '.$_GET['id'];
$cart=mysqli_query($con, $ssql);

$cartt="insert into cart(u_id,pid) values('".$_SESSION['user']."','".$_GET['id']."')";

	if(mysqli_query($con, $cartt))
	{
		
		header ("Location: view_cart.php"); 
		}
	else
	{
		echo"no";
	}
?>
