<?php

include "header.php";

include "conncetion.php";


?>
<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					<h4>Categories</h4>
				
				<?php
				mysqli_connect("localhost","root","");
				mysqli_select_db($con, "OBS");
				
				$res=mysqli_query($con, "select * from category");
				while($row=mysqli_fetch_assoc($res))
				{
				
				
				echo "<ul>";
				
				
					{
						echo '<li><a href="list.php?cat='.$row["id"].'">'.$row["cname"].'</a></li>';
					}
				
				echo "</ul>";
				}
				
				
				?>
					<br>
					<br>
						<li><img align="center" src="css/images/homeside.png" /></li>
						<li><img align="right"  /></li><br>
						<li><img align="right"  /></li><br>
						<li><img align="right" ></li><br>
				
				</li>
				
			</ul>
		</div>
		
		<div id="content">
			<!-- Products -->
			<div class="products">
				
				<?php
				$l = "select * from product p ,category  c where p.b_cat_id = c.id and p.b_cat_id = '".$_REQUEST["cat"]."'";
				$list=mysqli_query($con, $l);
				$row = mysqli_fetch_assoc($list);
					echo "<h3>".$row['bcategory']."</h3>";
				?>
				<?php
				
				$l = "select * from product p ,category  c where p.b_cat_id = c.id and p.b_cat_id = '".$_REQUEST["cat"]."'";
				$list=mysqli_query($con, $l);
				
				while($row = mysqli_fetch_assoc($list))
				
					{
						
							
					echo'
					<ul>
					<li>
						<div class="product">
							<a href="details.php?pid='.$row["p_id"].'""" class="info">
								<span class="holder">
									<img src="ADMIN/image/'.$row["bimage"].'" alt="" />
									<span class="book-name"><b>'.$row["bname"].'</b></span>
									<span class="author"><b>By <i> '.$row["bauthor"].'<i></b></span>
									
								</span>
							</a>
								<a href="details.php?pid='.$row["p_id"].'"" class="buy-btn">BUY NOW <span class="price"><span class="low"></span>'.$row["bprice"].'</span></a>
						</div>
					</li>

					
					';echo '</ul>';
					}
				
					
				
			
				?>	
			
				
				
				
			</div>	
			<div class="cl">&nbsp;</div>
			<?php
			include "footer.php";
			?>
	
