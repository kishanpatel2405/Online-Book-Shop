-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 24, 2019 at 08:50 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `obs`
--
CREATE DATABASE IF NOT EXISTS `obs` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `obs`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int(3) NOT NULL,
  `uname` varchar(10) NOT NULL,
  `pass` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `uname`, `pass`) VALUES
(1, 'Admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `u_id` varchar(50) NOT NULL,
  `pid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`u_id`, `pid`) VALUES
('.$_SESSION[''user''].', 0),
('Indrajit', 10);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cname`) VALUES
(1, 'Child'),
(2, 'Romance'),
(3, 'Politics'),
(4, 'Comics'),
(5, 'History'),
(6, 'Sports');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `subject` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `email`, `fname`, `lname`, `subject`) VALUES
(21, 'Indrajitsaresa@gmail.com', 'Indrajit', 'Saresa', 'romance book are good');

-- --------------------------------------------------------

--
-- Table structure for table `final_order`
--

CREATE TABLE IF NOT EXISTS `final_order` (
  `pid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `number` varchar(11) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `author` varchar(20) NOT NULL,
  `language` varchar(15) NOT NULL,
  `price` int(10) NOT NULL,
  `image` varchar(400) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `final_order`
--

INSERT INTO `final_order` (`pid`, `name`, `fname`, `lname`, `address`, `city`, `number`, `pname`, `category`, `author`, `language`, `price`, `image`, `date`) VALUES
(1, 'Indrajit', 'Indrajit', 'Saresa', 'rajkot', 'rajkot', '9512092355', 'Sita- Warrior of Mit', 'Child', 'Amish ', 'English', 245, 'sita.jpg', '2019-09-24');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_cat_id` int(40) NOT NULL,
  `bcategory` varchar(50) NOT NULL,
  `bname` varchar(25) NOT NULL,
  `bauthor` varchar(20) NOT NULL,
  `bprice` int(40) NOT NULL,
  `bpublisher` varchar(40) NOT NULL,
  `blanguage` varchar(20) NOT NULL,
  `bedition` varchar(30) NOT NULL,
  `bimage` varchar(800) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `b_cat_id`, `bcategory`, `bname`, `bauthor`, `bprice`, `bpublisher`, `blanguage`, `bedition`, `bimage`) VALUES
(1, 1, 'Child', 'Sita- Warrior of Mithila ', 'Amish ', 245, 'Westland', 'English', 'Paperback', 'sita.jpg'),
(2, 1, 'Child', 'Little Women', 'Alcott Louisa May Al', 850, 'Createspace Independent Publishing Platf', 'English', 'Paperback', 'little woman.jpg'),
(3, 1, 'Child', 'Jane Eyre (Step Into Clas', ' Charlotte Bronte,Ja', 715, 'Perfection Learning', 'English', 'Paperback', 'jane eyre.jpg'),
(4, 1, 'Child', 'New Moon', 'Stephenie Meyer', 250, 'Little, Brown Books for Young Readers', 'English', 'Paperback', 'new moon.jpg'),
(5, 1, 'Child', 'Adventures of Huckleberry', 'Mark Twain', 250, ' Naxos AudioBooks', 'English', 'Hardpaper', 'hulkberry.jpg'),
(6, 1, 'Child', 'Percy Jackson', ' Rick Riordan', 100, 'Puffin', 'English', 'Hardpaper', 'perc.jpg'),
(7, 1, 'Child', 'City of Ashes', 'Cassandra Clare', 250, 'Margaret K. McElderry Books', 'English', 'Paperback', 'city of ashes.jpg'),
(8, 1, 'Child', 'The Secret Garden', 'Frances Hodgson Burn', 150, 'Random House Value Publishing', 'English', 'Hardpaper', 'secret gardan.jpg'),
(9, 2, 'Romance', 'The Big Trip', ' George Dunford', 210, 'Lonely Planet Publications', 'English', 'Hardpaper', 'lonely.jpg'),
(10, 2, 'Romance', 'Congo', ' Michael Crichton', 160, 'Emece', 'English', 'Hardpaper', 'congo.jpg'),
(11, 2, 'Romance', 'Fever 1793', 'Laurie Halse Anderso', 200, 'Simon & Schuster Books ', 'English', 'Hardpaper', 'fever.jpg'),
(12, 2, 'Romance', 'Someone Like You', 'Sarah Dessen', 300, ' Penguin Young ', 'Hindi', 'Paperback', 'someone.jpg'),
(13, 2, 'Romance', 'A Piece of Cake', 'Cupcake Brown', 300, 'Crown/Archetype', 'Hindi', 'Paperback', 'cupcake.jpg'),
(14, 2, 'Romance', 'Heal Your Body', 'Louise L. Hay', 250, 'Hay House Inc', 'English', 'Paperback', 'heal.jpg'),
(15, 2, 'Romance', 'Pride ', 'Jane Austen', 120, 'Shutter Publishing', 'English', 'Hardpaper', 'pride.jpg'),
(16, 2, 'Romance', 'In Cold Blood ', ' Truman Capote', 220, ' Knopf Doubleday ', 'Hindi', 'Paperback', 'Cold Blood.jpg'),
(18, 3, 'Politics', 'The Hiding Place', 'Corrie ten Boom', 250, ' Chosen Books', 'English', 'Paper Back', 'hidden.jpg'),
(19, 3, 'Politics', 'A Christmas', 'Charles Dickens', 499, 'Barbara Dewolfe', 'English', 'Paper Back', 'A Christmas.jpg'),
(20, 3, 'Politics', 'Guns, Germs, and Steel', 'Jared Diamond', 399, 'Jony stark', 'English', 'Hard ', 'guns.jpg'),
(21, 3, 'Politics', 'The Prince', 'Machiavelli ', 299, ' Classic Books', 'English', 'Paper Back', 'The prince.jpg'),
(22, 3, 'Politics', 'The Art', 'Sun Tzu', 255, 'Classic Books', 'English', 'Hard Paper', 'the art.jpg'),
(23, 3, 'Politics', 'Number Of Stars', 'Lois Lowry', 120, 'Collins Children', 'Hindi', 'Paper Back', 'stars.jpg'),
(24, 3, 'Politics', 'Cold Blood', 'Truman', 199, 'Knopf', 'English', 'Hard Paper', 'Cold Blood.jpg'),
(25, 3, 'Politics', 'Othello', ' Christoph', 350, ' CreateSpace', 'Hindi', 'Paper Back', 'Othello.jpg'),
(26, 4, 'Comics', 'Naruto', 'Masashi', 500, 'Simon', 'English', 'Paper Back', 'Naruto.jpg'),
(27, 4, 'Comics', 'Fables', 'Bill ', 300, 'DC ', 'English', 'Hard Paper', 'Fables.jpg'),
(28, 4, 'Comics', 'Maus', ' Art', 155, 'Penguin ', 'English', 'Paper Back', 'Maus.jpg'),
(29, 4, 'Comics', 'Guards!', 'Terry', 500, 'Orion', 'English', 'Hard Paper', 'Guards!.jpg'),
(30, 4, 'Comics', 'Attack', 'Hajime', 800, 'Kodansha ', 'English', 'Paper Back', 'Attack.jpg'),
(31, 4, 'Comics', 'Fun Home', 'Alison', 600, ' Turtleback ', 'English', 'Hard Paper', 'Fun Home.jpg'),
(32, 4, 'Comics', 'Last Man ', 'Brian K', 450, 'DC', 'English', 'Paper Back', 'Last Man.jpg'),
(33, 4, 'Comics', 'Butler', 'Yana', 199, 'little', 'English', 'Hard Paper', 'Butler.jpg'),
(34, 5, 'History', 'Genghis Khan ', 'Jack ', 500, ' Crown', 'English', 'Hard Paper', 'Genghis Khan.jpg'),
(35, 5, 'History', 'the Year', 'Gavin', 455, ' Bantam', 'English', 'Hard Paper', 'the Year.jpg'),
(36, 5, 'History', 'On Wings', 'Ken Follett', 425, 'Durkin ', 'Hindi', 'Paper Back', 'On Wings.jpg'),
(37, 5, 'History', 'Freedom', 'Larry', 460, 'india publisher', 'Hindi', 'Hard Paper', 'Freedom.jpg'),
(38, 5, 'History', 'On China', 'Henry ', 300, 'Penguin', 'English', 'Hard Paper', 'On China.jpg'),
(39, 5, 'History', 'The Great Game', 'Peter', 455, ' Kodansha ', 'English', 'Paper Back', 'The Great Game.jpg'),
(40, 5, 'History', 'Jerusalem', 'Simon S', 460, 'Orion ', 'English', 'Paper Back', 'Jerusalem.jpg'),
(41, 5, 'History', 'The Rising', 'John W', 300, ' Ishi Press', 'English', 'Hard Paper', 'The Rising.jpg'),
(42, 6, 'Sports', 'The Test of My Life', ' Yuvraj Singh', 600, 'Ebury Press', 'Hindi', 'Paper Back', 'The Test of My Life.jpg'),
(43, 6, 'Sports', 'Kevin Pietersen', 'Kevin Pietersen', 500, ' Little', 'English', 'Hard Paper', 'Kevin Pietersen.jpg'),
(44, 6, 'Sports', 'Controversially Yours', 'Shoaib Akhtar', 455, 'Harper', 'Hindi', 'Paper Back', 'Controversially Yours.jpg'),
(45, 6, 'Sports', 'Chess Queen', 'Marilyn ', 620, 'HarperCollins', 'English', 'Paper Back', 'Chess Queen.jpg'),
(46, 6, 'Sports', 'Winning Chess', 'Yasser ', 520, ' Everyman ', 'English', 'Hard Paper', 'Winning Chess.jpg'),
(47, 6, 'Sports', 'True Believer', 'Nicholas', 500, 'Playaway', 'English', 'Paper Back', 'True Believer.jpg'),
(48, 6, 'Sports', 'Running', 'Haruki ', 500, ' Vintage ', 'English', 'Paper Back', 'Running.jpg'),
(50, 6, 'Sports', 'On Warne', 'Gideon Haigh', 150, ' Simon & Schuster', 'English', 'Hardpaper', '9781471101106_medium_75da252b4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `number` varchar(10) NOT NULL,
  `username` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `fname`, `lname`, `address`, `city`, `number`, `username`, `email`, `password`) VALUES
(5, 'Indrajit', 'Saresa', 'rajkot', 'rajkot', '9512092355', 'Indrajit', 'Indrajitsaresa@gmail.com', '12345');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
