<?php
	
	include "header.php";
	include "config.php";
	?>
	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
<style>
input[type=text],[type=email]{
    font-size:12.5px;
	width: 50%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: green	;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
</head>
<body> 
<div id="main" class="" >
		<!-- Sidebar -->
		 &nbsp; &nbsp;<div id="sidebar">
			<ul class="categories">
				<li>
						<li> <img align="right" src="css/images/sidecon.png" alt="" /></li>	
						<li><img align="right" src="css/images/sidecon2.png" alt="" /></li>
				</li>
			</ul>
		</div>
	</div>

<div class="containe" align="right" >
<h3  align="center"><font size="9" >&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Feedback Form</font></h3><br><br>
	<form  method="post" action="contact.php">
    <label><b>Email</b></label>&nbsp; &nbsp; 
	 <input type="email"  placeholder="Enter Email" name="email" required><br>
	 <label for="fname"><b>First Name</b></label>
    <input type="text" id="fname" name="fname" placeholder="Your name.."required><br>

    <label for="lname"><b>Last Name</b></label>
    <input type="text" id="lname" name="lname" placeholder="Your last name.."required><br>
<label for="subject"><b>Subject</b></label>
    <input type="text" id="subject" name="subject" placeholder="Write something.." required>	
<br>
    <input type="submit" name="submit" value="Submit">
  </form>
</div>
<?php

	include "footer.php";
?>