<?php
include "header.php";
include "conncetion.php";
include "config.php";

?>

<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					</li>
				</ul>
		</div><div id="main" class="" >
			
	<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
	
		<li><img height="200" width="180" align="right" src="css/images/carton.png" alt="" /></li>	
						<li><img height="200" width="180" align="right" src="css/images/book animation.gif" alt="" /></li>	
						<li><img height="200" width="180" align="right" src="css/images/cartoon.jpg" alt="" /></li>	
						</li>
				
				</li>
			</ul>
			</div>

	<div align="center" class="logoo">

<img src="css/images/loginlogo.png">
</div>				</div>
	

	<?php
	$q= "SELECT * FROM `signup` WHERE username= '".$_SESSION['user']."'";
	
		$res=mysqli_query($q);
		$row = mysqli_fetch_assoc($res);
	?>	
	<div class="container" align="center">
<font size="4">
<label><b>First Name :</b></label>
&nbsp;&nbsp;<?php echo $row["fname"] ?><br><br>

								<label><b>Last Name :</b></label>
								&nbsp;&nbsp;<?php echo $row["lname"] ?><br><br>
								
								
									<label><b>Address :</b></label>
								&nbsp;&nbsp;<?php echo $row["address"] ?><br><br>
								
								<label><b>City :</b></label>
								&nbsp;&nbsp;<?php echo $row["city"] ?><br><br>
								
																
								<label><b>Phone No :</b></label>
								&nbsp;&nbsp;<?php echo $row["number"] ?><br><br>
								<label><b>Username :</b></label>
								&nbsp;&nbsp;<?php echo $row["username"] ?><br><br>
								
								<label><b>Email :</b></label>
								&nbsp;&nbsp;<?php echo $row["email"] ?><br><br></font>
								
	<?php
	$z="select * from `final_order` WHERE name= '".$_SESSION['user']."'";
	$chq=mysqli_query($z);
	$chk = mysqli_fetch_row($chq); 
	if($chk[0] != '') 
	{
	$fet=mysqli_query($z);
	$total_price = 0;
	echo "<h3> Your Order</h3><br>";
	echo "<table border='1'>";
	echo "<th>Book Name </th>";
	echo "<th>Book Category </th>";
	echo "<th>Book Auhtor </th>";
	echo "<th>Book Language </th>";
	echo "<th>Book Price </th>";
	echo "<th>Book Date </th>";
	echo "<th> Image </th>";
	echo "<th>Cancel Order </th>";
		while ($det = mysqli_fetch_assoc($fet))
		{		
			echo "<tr>";
			 echo "<td>".$det['pname']."</td>";
			 echo "<td>".$det['category']."</td>";
			 echo "<td>".$det['author']."</td>";
			 echo "<td>".$det['language']."</td>";
			 echo "<td>".$det['price']."</td>";
			 echo "<td>".$det['date']."</td>";
			 echo "<td><img height='80' width='66' src='ADMIN/image/".$det['image']."' /></td>";
			echo "<td> <a href='delorder.php?id=".$det['pid']."'>Cancel Order</a></td>";
			echo "</tr>";
			$total= $total_price += $det['price'] ;
		}
		echo "</table><br><br>";
		echo "<h3 align='right'> Grand Total : ".@	$total."</h3>";
	}
	else{echo ""; }
	include "footer.php";
	?>