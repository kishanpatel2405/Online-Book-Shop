
<?php
 include "header.php";
 include "conncetion.php";
 ?>
 
 <div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	<div id="main" class="" >
			<div align="center" class="logoo">

<img src="css/images/loginlogo.png">
</div>				<br><br>

 <?php
$nm = $_SESSION['user'];
$sql = "select id,fname,lname,username,address,city,number,email from signup where username='$nm'";
 $user = mysqli_query($con, $sql);
$fetch = mysqli_fetch_assoc($user);
 ?>
 	<div class="container" align="center">
<font size="4">
<label><b>First Name :</b></label>
&nbsp;&nbsp;<?php echo $fetch["fname"] ?><br><br>

								<label><b>Last Name :</b></label>
								&nbsp;&nbsp;<?php echo $fetch["lname"] ?><br><br>
									<label><b>Address :</b></label>
								&nbsp;&nbsp;<?php echo $fetch["address"] ?><br><br>
								<label><b>City :</b></label>
								&nbsp;&nbsp;<?php echo $fetch["city"] ?><br><br>
							<label><b>Phone No :</b></label>
								&nbsp;&nbsp;<?php echo $fetch["number"] ?><br><br>
								<label><b>Email :</b></label>
								&nbsp;&nbsp;<?php echo $fetch["email"] ?><br><br></font>
								
 
 </div>
 <br><br>
 <?php
  if(isset($_POST['submit']) && $_POST['submit']=='Buy Now')
{
	for($i=1;$i<=$_POST['products'];$i++){
	$id = $_POST["pr$i"];
	$nm = $_SESSION['user'];
	$date = date('Y/m/d');
	$pro = $_POST["prname$i"];
	$primage = $_POST["primage$i"];
	$prcategory = $_POST["prcategory$i"];
	$pr = $_POST["prprice$i"];
	$prauthor = $_POST["prauthor$i"];
	$prlanguage = $_POST["prlanguage$i"];
	$sql1 = "select id,fname,lname,username,address,city,number from signup where username='$nm'";
					$userdt = mysqli_query($con, $sql1);
					$name; $addr;
					while($row = mysqli_fetch_assoc($userdt))
					{
						$name = $row['username'];
						$addr = $row['city'];
						$fnam = $row['fname'];
						$lnam = $row['lname'];
						$add = $row['address'];
						$nmber = $row['number'];
						
						
					}
	$sql = "insert into final_order values($id,'$nm','$fnam','$lnam','$add','$addr','$nmber','$pro','$prcategory','$prauthor','$prlanguage','$pr','$primage','$date')";
	mysqli_query($con, $sql);
	
	
					if($i==1) {
					echo "<h3 style= font-size:35px;><center> Your Bill </center><br><br></h3>";
						echo "<div align='center'style= font-size:27px; color:white;'><table border='2'><tr>
						<th>Product</th><th>Category</th><th>Author</th>
						<th>Language</th><th>Price</th><th>Order Date</th><th>Image</th></tr>";
					}
					
					
					$tp;

					$sql3 = "select date from final_order where pid='$id'";
					$dtdt = mysqli_query($con, $sql3);
					$add;
					while($row = mysqli_fetch_assoc($dtdt))
					{
						$dt = $row['date']; 
					}
					echo "<td>$pro</td><td>$prcategory</td><td>$prauthor</td><td>$prlanguage</td><td>$pr</td><td>$dt</td>
					<td><img width='60' height='70'src='ADMIN/image/$primage'></td></tr>";
					if($i==$_POST['products']){
						echo "</table><br><BR>";
						if(isset($_POST['submit']) && $_POST['submit']=='Buy Now')
						echo "<b><h3>Grand Total : ".$_POST['total']."</b><br><br></h3><h3 align='center'> Your Order Placed Succesfully.......</h3><br><br><br><br>";
						else echo "<p align='center'> Order  Not  confirm.....!";
						echo "<h3 align='center'><a href='index.php'>Back To Shopping</a> </h3>";
						echo "</div><br />";
					}
	 $delete = "delete from cart where pid=$id";
	 mysqli_query($con, $delete);
	}
}

?>
 <?php
	include "footer.php";		
			
?>				
</div>