<?php

	include "header.php";
?>
	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					
				</li>
				
			</ul>
		</div>
	<!-- End Slider -->
	<!-- Main -->
	<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
				<li><img align="right" src="css/images/aboutbook.png" alt="" /></li>	
					&nbsp;	<li><img align="right" src="css/images/aboutbook1.png" alt="" /></li>
				</li>
			</ul>
		</div>
	</div>
<h3 align="center"><font size="9">&nbsp;About Us</font> </h3><br><br>
<form align="left">
  <div class="containe" align="center">
    <h3 ><font size="3"> 
	<p>Welcome to Book Depository, the world's leading specialist online bookstore. We're proud to offer over 17 million titles, all at unbeatable prices with free delivery worldwide to over 100 countries. Whatever your interest or passion, you'll find something interesting in our bookshop full of delights.</p><br><br>
	
	<p>When it comes to searching for books, there is only one place to turn to – the Best Sellers. We are India's largest online book store and rightly so. Having served some of the best in the industry for over 5 years – we are your one stop solution for all your book needs.</p><br><br>
	</div>
	<div align="left"><h3><font size="3"> 
	Name : Kishan Vaghasiya	<br>
	Phone No : 9723617944 <br>
	</h3><br><br>
	
				<h3 ><center><font size="15" face="verdena">Thank You!</center></h3>
	</h3>
 </font></form>
 </div>
  
   
  <br><br>
<?php
	include "footer.php";
?>
</body>
</html>

