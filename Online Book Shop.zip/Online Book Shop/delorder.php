<?php
include "conncetion.php";

	
//	include"connect.php";
	$s="delete from final_order where pid=".$_GET['id'];
	
	if( $data=mysqli_query($s))
		
	{
			
			
		header("Location: profile.php");
	}
	else
	{
		echo "No";
	
	}
	
	
?>
