<?php

include "header.php";
include "conncetion.php";	
?>



	<div id="main" class="shell">
		<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				
				
			</ul>
		</div>
		<!-- End Sidebar -->
		<!-- Content -->
	

<div id="main" class="" >
		<!-- Sidebar -->
		<div id="sidebar" >
			<ul class="categories">
				<li>
				
					
					<li><img align="right" src="css/images/sidelog2.png" alt="" /></li>
				</li>
				
			</ul>
		</div>
	</div>
<div>
<div>

			<div class="products">
				<form action="process_cart.php" method="post" >
								<table width="100%" border="0">
									<tr>
										<td></td>
										<td width="10%">No</td>
										<td width="30%">Book Name</td>
										<td width="30%">Book Category</td>
										<td width="10%" align="right">Price</td>
										<td width="10%" align="right">Qty</td>
										<td width="10%" align="right">Value</td>
									</tr>
									<?php
									
									
									$d="select bname,bcategory,bprice from product where  p_id = '".$_REQUEST["pid"]."'"; 
									if(!isset($result = mysqli_query($l)))
									{
											echo "cart is empty";
									}
									if($result = mysqli_query($l))
									$p_row = mysqli_fetch_assoc($result);
										$i = 1;
										$tot = 0;
									//	$SESSION
										
											{
											echo '
												<tr>
													<tD><a href="process_cart.php?del='.$c["pid"].'">x</a></td>
													<td>'.$i++.'</td>
													<td>'.$p_row["bname"].'</td>
													<td>'.$p_row["bcatgory"].'</td>
													<td align="right">'.$p_row["bprice"].'</td>
													<td align="right"><input type="text" name="'.$_REQUEST["pid"].'" value="'.$c["qty"].'" size="2" /></td>
													<td align="right">'.($p_row["bprice"] * $c["qty"]).'</td>
												</tr>
											';
												
											$tot += ($c["bprice"] * $c["qty"]);
										}
									?>
									<tr><td colspan="7"><hr color="#a1a1a1" size="2" /></td></tr>
									<tr>
										<td colspan="6" align="right"><b><big>Total</big></b></td>
										<td align="right"><b><big><?php echo $tot; ?></big></b></td>
									</tr>
									<tr><td colspan="7"><hr color="#a1a1a1" size="1" /></td></tr>
								</table>
								<input type="submit" value="Refresh" />
								</form>

<?php

include "footer.php";
?>




