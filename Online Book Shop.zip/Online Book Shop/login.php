<?php
include "conncetion.php";
session_start();


 if($_POST["submit"]=="Login")
{
  $user=$_POST['username']; 
$pass=$_POST['password'];
$sql="select * from signup form where username='".$user."' and password='".$pass."'";
$result=mysqli_query($con, $sql);
$row=mysqli_fetch_array($result);
}
if($user==$row['username'] && $pass==$row['password'])
{
	$_SESSION['user']=$row['username'];
	header('Location:logincheck.php');
	
}
else
{	
	$_SESSION['login'] = 2; 
	header('Location:loginform.php');
	//header("Location:loginform.php");
}

		
?>