<?php


?>

<div class="cl" >&nbsp;</div>
			<!-- Best-sellers -->
			<div id="best-sellers" align="center">
				
			</div>
			<!-- End Best-sellers -->
		</div>
		<!-- End Content -->
		<div class="cl">&nbsp;</div>
	</div>
	<!-- End Main -->
	<!-- Footer -->
	<div id="footer" class="shell">
		<div class="top">
			<div class="cnt">
				<div class="col about">
					<h4>About BestSellers</h4>
					<p>When you shop online, there are hot pre-orders. You can easily secure that book you’ve always wanted to read, as the book will be delivered at your doorstep soon after its official release. You also have easy access to most of the new arrivals, with book descriptions that help you get an idea about the book without spoilers. <br /><br><br><font size="5">Best Sellers </Font> </p>
				</div>
				<div class="col store">
					<h4>Store</h4>
					<ul>
						<li><a href="index.php">Home</a></li>
						
						<li><a href="index.php">Products</a></li>
		<?php
	
				if(isset($_SESSION['user']))
				{
				echo '<li><a href="logout.php">Log Out</a></li>';
		
				}
				else
				{	
				echo '<li><a href="signupform.php">Sign Up</a></li>';
				echo '<li><a href="loginform.php" >Log In</a></li>';
				}
				?>
						<li><a href="ADMIN/adminlogin.php">Only For Admin</a></li>
					</ul>
				</div>
				<img src="css/images/bottom.png">
				<div class="cl"></div>
				<div class="copy">
					<a href="index.php"><p> <marquee behavior="alternate"><font color="white" face="verdena" size=
"5">Best Seller - <i>Online Book Shop<br><br></font></marquee></p></a>

					<center> <font color="white" size="3">Created By: Kishan Vaghasiya</font></center></div>
				
			</div>
		</div>
	</div>
	<!-- End Footer -->