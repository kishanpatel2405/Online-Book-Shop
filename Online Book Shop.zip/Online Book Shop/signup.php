<?php
include "conncetion.php";
if($_POST["submit"]=="Submit")
{
		$fname=$_POST["fname"];
		$lname=$_POST["lname"];	
		$address=$_POST["address"];	
		$city=$_POST["city"];	
		$number=$_POST["number"];	
		$username=$_POST["username"];	
		$email=$_POST["email"];	
		$password=$_POST["password"];
  
	$s="insert into signup(fname,lname,address,city,number,username,email,password)values('".$fname."','".$lname."','".$address."','".$city."','".$number."','".$username."','".$email."','".$password."')";
	
	if(mysqli_query($con, $s))
	{
		header("Location: loginform.php");
	}
	else
		header("Location: signupform.php");
}

else
	
	{
		
		echo "not conncet";
	}
?>
	
	