<?php
include "conncetion.php";
session_start();

if($_POST["submit"]=="Submit")
{
		$email=$_POST["email"];	
		$fname=$_POST["fname"];
		$lname=$_POST["lname"];	
		$subject=$_POST["subject"];	
		

		$s="insert into contact(email,fname,lname,subject)values('".$email."','".$fname."','".$lname."','".$subject."')";
	
	if(mysqli_query($s))
	{
			$_SESSION['cont'] = 1; 
				header('Location:index.php');
	}
	else
		echo "not save";
}